#!/bin/bash
# Info   : check conf to reload server
# Author : dingtm
# CTime  : 2010.06.30
# This script run at every one minutes

Sdir=/elain/data/htdocs/wwwelainorg/conf                                                                                     
Ddir=/elain/apps                                                                                                          
                                                                                                                          
if [ $Sdir/nginx.conf -nt $Ddir/nginx/conf/nginx.conf ]                                                                   
   then                                                                                                                   
   /bin/cp $Sdir/nginx.conf $Ddir/nginx/conf/                                                                             
   /elain/apps/nginx/sbin/nginx -s reload                                                                                 
       if [ $? = 0 ]                                                                                                      
         then                                                                                                             
              echo "`date +%Y-%m-%d-%H:%M:%S` nginx reload ok " >>$Sdir/success.log                                       
          else                                                                                                            
              echo "`date +%Y-%m-%d-%H:%M:%S` nginx reload fail " >>$Sdir/error.log                                       
      fi                                                                                                                  
   else                                                                                                                   
   exit 1                                                                                                                 
fi   
chown www.www $Sdir/*.log

