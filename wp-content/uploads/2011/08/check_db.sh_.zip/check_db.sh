#!/bin/bash                                                                                                               
# Info   : check mysql slave                                                                                              
# Author : dingtm                                                                                                         
# CTime  : 2011.03.21                                                                                                     
# This script run by root                                                                                                 
                                                                                                                          
DBDir=/elain/apps/mysql/bin/                                                                                              
DBSock=/elain/data/mysql/3306/mysql.sock                                                                                  
Log=/tmp/mysql_slave.log                                                                                                  
DBUser=root                                                                                                               
DBPasswd=elain                                                                                                       
MailList=elain@elain.org,elain2012@hotmail.com                                                                               
                                                                                                                          
Seconds_Behind_Master=$(${DBDir}mysql -u${DBUser} -p${DBPasswd} -S ${DBSock} -e "show slave status\G;" | awk -F':' '/Seconds_Behind_Master/{print $2}')                                                                                             
                                                                                                                          
if [ ${Seconds_Behind_Master} != "NULL" ];                                                                                
    then                                                                                                                  
         echo "slave is ok!"                                                                                              
else                                                                                                                      
${DBDir}mysql -u${DBUser} -p${DBPasswd} -S ${DBSock} -e "show slave status\G;" >$Log                                      
/usr/bin/sendEmail -f admin@elain.ort -t $MailList -s mail.elain.org -xu 'admin@elain.org' -xp 'elain@123' -u "[`date +%Y-%m-%d`]数据库不同步了，请赶快看看吧！" -m "`cat $Log`"                                                      
fi 
