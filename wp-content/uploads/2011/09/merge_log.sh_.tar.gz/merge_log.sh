# Info   : merge log for many server log
# Author : dingtm                                                                                                    
# CTime  : 2011.03.01  

DAY=`date -d '-1 day' +%Y/%m/%d`                                                                 
mkdir -p /data/logs/$DAY/merge_logs/   #建立合并后的日志文件存放目录

OldLog=/data/logs/$DAY                 #各服务器的日志文件，以日期为目录，各服务器主机名为子目录
NewLog=/data/logs/$DAY/merge_logs      

for log in access_ebook.elain.org.log access_www.elain.org.log access_blog.elain.org.log access_books.elain.org.log access_bbs.elain.org.log
  do
    sort -m -t " " -k 4 -o  $NewLog/$log $OldLog/web01/$log $OldLog/web02/$log $OldLog/web03$log $OldLog/web04/$log
done

