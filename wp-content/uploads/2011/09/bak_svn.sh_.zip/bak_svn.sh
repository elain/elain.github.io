#!/bin/bash                                                                                                               
#Author  :elain                                                                                                          
#Ctime   :20110805                                                                                                        
                                                                                                                          
Bak_Dir=/data/svnbak                                                                                               
Svn_Dir=/data/svndata
Svn_data=/data/svnbak/svndata_`date +%Y%m%d`.tar.gz
MailList=elain2012@hotmail.com

# Info   : 每周备份一次svn数据
/bin/tar zcf $Svn_data /data/svndata

# Info   : 邮件正文
echo -e "==========`date +%Y年%m月%d日` SVN 备份数据==========" >$LogFile
echo -e "SVN备份文件:\nsvndata_`date +%Y%m%d`.tar.gz \n大小:`du -sh $Svn_data |awk '{print $1}'`" >>$LogFile
echo -e "==============by:elain www.elain.org=================\n详情参见附件!" >>$LogFile

# Info   : 发送邮件
/usr/bin/sendEmail -f admin@elain.org -t $MailList -s mail.elain.org -xu 'admin@elain.org' -xp 'elain123we' -u "`date +%Y年%m月%d日` SVN备份数据" -m "`cat $LogFile`" -a $Svn_data

# Info   : 删除七天前的备份
find $Bak_Dir -mtime +7 | xargs rm -rf

